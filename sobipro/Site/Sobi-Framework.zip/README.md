# Sobi Framework

Since version 1.3.3, SobiPro uses the Sobi Framework for common functions. This is the first step needed to provide our community with additional components in the future.

Read more in https://www.sigsiu.net/center/sobipro-component/154-sobi-framework